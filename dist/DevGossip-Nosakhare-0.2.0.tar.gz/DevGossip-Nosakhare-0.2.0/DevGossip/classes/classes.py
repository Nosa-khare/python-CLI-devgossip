class bcolors:

    HEADER = '\033[95m'

    BLUE = '\033[34m'
    LBLUE = '\033[94m'
    CYAN = '\033[36m'
    LCYAN = '\033[96m'

    PURPLE = '\033[35m'

    GREEN = '\033[32m'
    LGREEN = '\033[92m'

    YELLOW = '\033[33m'
    LYELLOW = '\033[93m'

    RED = '\033[31m'
    LRED = '\033[91m'
    
    PINK = '\033[91m'
    
    LGREY = '\033[37m'

    ENDC = '\033[0m'  # End effect

    UNDERLINE = '\033[4m';	'\033[21m'

    BOLD = '\033[1m'

    ITALIC = '\033[3m'

    HILIT = '\033[7m'
    HILITRED = '\033[41m'
    HILITGREEN = '\033[42m'
    HILITYELLOW = '\033[43m'
    HILITBLUE = '\033[44m'
    HILITPURPLE = '\033[45m'
    HILITCYAN = '\033[46m'
    HILITGREY = '\033[47m'
    HILITG = '\033[51m'

    CANCEL = '\033[9m'

    GLOW = '\033[30m'
